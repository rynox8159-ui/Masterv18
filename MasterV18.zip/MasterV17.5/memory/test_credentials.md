# Test credentials (MasterV17.3)
- Backend API key header: X-API-Key: nq_CNy5O2RnYvN0aAvYvAUzBXdiEah0Sve6_c4eAMNyclU  (built-in key, shared automatically by the frontend; no login screen)
- Auto trade REAL operator key (X-Autotrade-Real-Key / typed in the Real confirm dialog): rk_Nw04tdJiI7gIgmA2D9RG8Odm2zD7e5TS
- Deriv demo account is authorised automatically from DERIV_API_TOKEN_1 (demo) / DERIV_API_TOKEN_2 (real) in main_source_code/backend/.env
  (optional overrides: DERIV_DEMO_TOKEN / DERIV_LIVE_TOKEN).
- No user accounts / passwords exist in this app.

## Auto trade API (V17.3)
- GET  /api/v1/autotrade/status            -> running, mode (demo|real|both), modes[], states{demo,real}, accounts{...}, settings, logs
- POST /api/v1/autotrade/start {"mode":"demo"}            (demo, no confirmation)
- POST /api/v1/autotrade/start {"mode":"real"|"both","confirmReal":true,"confirmText":"REAL"} + header X-Autotrade-Real-Key
- POST /api/v1/autotrade/stop | /kill | /settings {...} | GET /trades?mode=demo|real|both
- Settings added in V17.3: minSignalConfidence (0 = all signals), martingaleEnabled, martingaleMultiplier, martingaleMaxSteps
- Training: GET /api/v1/ml/pipeline, POST /api/v1/ml/train-all, POST /api/v1/ml/retrain-active {"hours":24}
- Backend tests: `cd main_source_code/backend && python -m pytest tests/ -q` (BACKEND_TEST_URL defaults to http://localhost:8001; /app/memory/api_key.txt holds the API key)
